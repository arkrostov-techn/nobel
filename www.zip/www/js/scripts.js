window.addEventListener('scroll', function() {
  const parallaxBlock = document.querySelector('.parallax-block');
  const scrollPosition = window.scrollY;

  // Изменяем скорость движения фона
  const speed = 0.2; // Можно изменять для более медленного или быстрого движения
  parallaxBlock.style.backgroundPositionY = `${scrollPosition * speed}px`;
});
